create definer = root@localhost view vistapreguntas as
select `p`.`id_pregunta`         AS `id_pregunta`,
       `p`.`categoria`           AS `categoria`,
       `p`.`dificultad`          AS `dificultad`,
       `p`.`contenido`           AS `contenido`,
       `p`.`opcion_A`            AS `opcion_A`,
       `p`.`opcion_B`            AS `opcion_B`,
       `p`.`opcion_C`            AS `opcion_C`,
       `p`.`opcion_D`            AS `opcion_D`,
       `p`.`respuesta_correcta`  AS `respuesta_correcta`,
       `p`.`habilitado`          AS `habilitado`,
       `p`.`estado`              AS `estado`,
       `p`.`cant_total_aciertos` AS `cant_total_aciertos`,
       `p`.`fecha`               AS `fecha`,
       `u`.`nombre_usuario`      AS `editor`
from (`quizstorm`.`pregunta` `p` left join `quizstorm`.`usuario` `u` on (`p`.`id_editor` = `u`.`id_usuario`));

